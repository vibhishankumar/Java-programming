import emp.*;
import java.util.*;
public class tut1{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter name of employe :");
        String name=sc.nextLine();
        System.out.println("Enter id of employe :");
        int idd=sc.nextInt();
        System.out.println("Enter age of employe :");
        int age=sc.nextInt();
        employeemp obj=new employeemp(idd);
        obj.setname(name);
        obj.setage(age);
        obj.display();
        obj.show();
    }
}