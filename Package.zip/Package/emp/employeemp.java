package emp;
class persion{
    String name;
    int age;
    public void setname(String str)
    {
        this.name=str;
    }
    public void setage(int n)
    {
        this.age=n;
    }
    public String getname()
    {
        return this.name;
    }
    public int getage()
    {
        return this.age;
    }
    public void display()
    {
        System.out.println(getname() + " " + getage());
    }
}
public class employeemp extends persion{
    int id;
    public employeemp(int id_n)
    {
       this.id=id_n;
    }
    public int getId()
    {
        return this.id;
    }
    public void show()
    {
        System.out.println(getname() + " "+ getage() +" "+ getId());
    }
}